

// The dialog style and structure
$('.dialogs').dialog({
  draggable: true, 
  resizable: false, 
  height: 500, 
  width: 800,
  modal: true,
  show: 1000,
  hide: '1000',
  autoOpen: false,       
  buttons : {
    "Book Now" : function(){                
      $(this).dialog("close");
    },
  }
});



// The links to the content of the rooms and suites information based on the click
$("#supLink").click(function() {
  $('#supDialog').dialog("open");
});

$("#delLink").click(function() {
  $('#delDialog').dialog("open");
});

$("#doubleLink").click(function() {
  $('#doubleDialog').dialog("open");
});

$("#suite1Link").click(function() {
  $('#suite1Dialog').dialog("open");
});

$("#suite2Link").click(function() {
  $('#suite2Dialog').dialog("open");
});

$("#suite3Link").click(function() {
  $('#suite3Dialog').dialog("open");
});





// Making the dialog box responsive to different screen sizes

$(window).resize(function(){
  if($(window).width() < 800){
  $('.dialogs').dialog({
  height: 400, 
  width: 300
  });
  }
});


$(window).resize(function(){
  if($(window).width() > 800){
  $('.dialogs').dialog({
  height: 500, 
  width: 800
  });
  }
});



$(document).ready(function(){

  if($(window).width() < 500){
  $('.dialogs').dialog({
  height: 400, 
  width: 300
  });
  }
});



  
