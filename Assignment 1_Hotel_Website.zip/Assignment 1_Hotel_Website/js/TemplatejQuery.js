
// The jquery code of the comment section
function saveComment(){

    var com = '<div class="comment group"><h3>'+$('input').val() + '</h3>';
    var dt = new Date();
    com += '<span class="group">' + dt.getDate() + "/" + dt.getMonth() + "/" + dt.getFullYear() +
    "&emsp;" + dt.getHours() + ":" + dt.getMinutes() +'</span> <br/><br/>';
    com += '<pre>' + $('textarea').val() + '</pre> </div>';

    if($('textarea').val() === "NOT"){
        $(".commentStorage").empty();
    }

    if ($('input').val('')){

        $('input').val('Anon');
    }

    var preCom = $('.commentStorage').html();

    $('.commentStorage').empty();            
    $('.commentStorage').append(com);
    $('.commentStorage').append(preCom);
    clearComment();

    preCom = $('.commentStorage').html();
    setObject('commentStorage', preCom);



}





function clearComment(){
    $('input').val('');
    $('textarea').val('');
}

function setObject(key, value) {
    window.localStorage.setItem(key,
        JSON.stringify(value));
};


function getObject(key) {
    var commentStorage = window.localStorage;
    var value = commentStorage.getItem(key);
    return value && JSON.parse(value);

};


if (getObject('commentStorage') === null){
    var preCom = '';
} else {
    var preCom = getObject('commentStorage');
};


function clearStorage() {
    // removes everything placed in localstorage
    window.localStorage.clear();
};

        
$('.commentStorage').append(preCom);



// The jquery code of the comment section END